var _graph_observer_8h =
[
    [ "GraphObserver", "classogdf_1_1_graph_observer.html", "classogdf_1_1_graph_observer" ],
    [ "OGDF_GRAPH_STRUCTURE_H", "_graph_observer_8h.html#a786155a9589e05e885485c5850e86062", null ]
];