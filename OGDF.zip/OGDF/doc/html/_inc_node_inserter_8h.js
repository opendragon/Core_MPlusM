var _inc_node_inserter_8h =
[
    [ "IncNodeInserter", "classogdf_1_1_inc_node_inserter.html", "classogdf_1_1_inc_node_inserter" ],
    [ "OGDF_INCNODEINSERTER_H", "_inc_node_inserter_8h.html#adba6048ddc0cadf2c30826ad2c067179", null ]
];