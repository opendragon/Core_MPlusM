var _embedder_module_8h =
[
    [ "EmbedderModule", "classogdf_1_1_embedder_module.html", "classogdf_1_1_embedder_module" ],
    [ "OGDF_EMBEDDER_MODULE_H", "_embedder_module_8h.html#af43ffd05d800b60d52f6be4bbf277920", null ]
];