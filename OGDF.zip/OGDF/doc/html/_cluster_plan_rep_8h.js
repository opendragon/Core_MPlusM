var _cluster_plan_rep_8h =
[
    [ "ClusterPlanRep", "classogdf_1_1_cluster_plan_rep.html", "classogdf_1_1_cluster_plan_rep" ],
    [ "OGDF_CLUSTER_PLAN_REP_H", "_cluster_plan_rep_8h.html#a915575df8a13c7b43d4fc510e0f5a24b", null ]
];