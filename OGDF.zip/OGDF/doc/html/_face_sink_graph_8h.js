var _face_sink_graph_8h =
[
    [ "FaceSinkGraph", "classogdf_1_1_face_sink_graph.html", "classogdf_1_1_face_sink_graph" ],
    [ "OGDF_FACE_SINK_GRAPH_H", "_face_sink_graph_8h.html#adb426995aad406717705d3ec4587bf86", null ]
];