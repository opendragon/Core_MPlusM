var _embedder_max_face_8h =
[
    [ "EmbedderMaxFace", "classogdf_1_1_embedder_max_face.html", "classogdf_1_1_embedder_max_face" ],
    [ "OGDF_EMBEDDER_MAX_FACE_H", "_embedder_max_face_8h.html#a69105364079afc9777a7bf6c2ed3c9df", null ]
];