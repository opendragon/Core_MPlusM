var _edge_comparer_simple_8h =
[
    [ "EdgeComparerSimple", "classogdf_1_1_edge_comparer_simple.html", "classogdf_1_1_edge_comparer_simple" ],
    [ "OGDF_EDGECOMPARER_SIMPLE_H", "_edge_comparer_simple_8h.html#a5ee4c9a318746dff6f468c825a3ec1c4", null ]
];