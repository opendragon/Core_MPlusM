var _cluster_set_8h =
[
    [ "ClusterSet", "classogdf_1_1_cluster_set.html", "classogdf_1_1_cluster_set" ],
    [ "ClusterSetPure", "classogdf_1_1_cluster_set_pure.html", "classogdf_1_1_cluster_set_pure" ],
    [ "ClusterSetSimple", "classogdf_1_1_cluster_set_simple.html", "classogdf_1_1_cluster_set_simple" ],
    [ "OGDF_NODE_SET_H", "_cluster_set_8h.html#adbe49388845e597b7ce9d27405608aca", null ]
];