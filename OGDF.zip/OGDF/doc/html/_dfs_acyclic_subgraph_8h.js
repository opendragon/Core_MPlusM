var _dfs_acyclic_subgraph_8h =
[
    [ "DfsAcyclicSubgraph", "classogdf_1_1_dfs_acyclic_subgraph.html", "classogdf_1_1_dfs_acyclic_subgraph" ],
    [ "OGDF_DFS_ACYCLIC_SUBGRAPH_H", "_dfs_acyclic_subgraph_8h.html#ad96289622e0a8d1547cb9002ddb98e50", null ]
];