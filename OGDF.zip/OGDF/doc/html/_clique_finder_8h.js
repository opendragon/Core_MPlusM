var _clique_finder_8h =
[
    [ "CliqueFinder", "classogdf_1_1_clique_finder.html", "classogdf_1_1_clique_finder" ],
    [ "OGDF_CLIQUEFINDER_H", "_clique_finder_8h.html#a44c29f9e03db636ad14c11dbace41d3f", null ]
];