var _intersection_rectangle_8h =
[
    [ "IntersectionRectangle", "classogdf_1_1_intersection_rectangle.html", "classogdf_1_1_intersection_rectangle" ],
    [ "OGDF_INTERSECTION_RECTANGLE_H", "_intersection_rectangle_8h.html#a496d51de497fa39cfc1804f527da63cf", null ]
];