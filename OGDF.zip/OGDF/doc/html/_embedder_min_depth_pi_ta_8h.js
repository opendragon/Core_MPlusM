var _embedder_min_depth_pi_ta_8h =
[
    [ "EmbedderMinDepthPiTa", "classogdf_1_1_embedder_min_depth_pi_ta.html", "classogdf_1_1_embedder_min_depth_pi_ta" ],
    [ "OGDF_EMBEDDER_MIN_DEPTH_PITA_H", "_embedder_min_depth_pi_ta_8h.html#a32c08d1d98a0d2291c8e870e3b8365e9", null ]
];