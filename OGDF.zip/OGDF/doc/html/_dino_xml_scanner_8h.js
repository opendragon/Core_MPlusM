var _dino_xml_scanner_8h =
[
    [ "DinoXmlScanner", "classogdf_1_1_dino_xml_scanner.html", "classogdf_1_1_dino_xml_scanner" ],
    [ "OGDF_DINO_XML_SCANNER_H", "_dino_xml_scanner_8h.html#ad52b1489567961ab2464added7ce00b9", null ],
    [ "XmlToken", "_dino_xml_scanner_8h.html#a822fe23411206276c7065c10a6689b6c", [
      [ "openingBracket", "_dino_xml_scanner_8h.html#a822fe23411206276c7065c10a6689b6ca219a2212ec1ba0fdf94d52bb0554d18b", null ],
      [ "closingBracket", "_dino_xml_scanner_8h.html#a822fe23411206276c7065c10a6689b6ca08d3c0ae2e9f378b20038541b2238b56", null ],
      [ "questionMark", "_dino_xml_scanner_8h.html#a822fe23411206276c7065c10a6689b6caf47cb6b5da8850ca599bd3b1d6c94587", null ],
      [ "exclamationMark", "_dino_xml_scanner_8h.html#a822fe23411206276c7065c10a6689b6cacd8ed505eb4dbe5c8213676550c240f8", null ],
      [ "minus", "_dino_xml_scanner_8h.html#a822fe23411206276c7065c10a6689b6cae7104b46d019abe16a02bf0b1e9d7fb3", null ],
      [ "slash", "_dino_xml_scanner_8h.html#a822fe23411206276c7065c10a6689b6ca3f802a8add6aa8d3f188fe735e2a2462", null ],
      [ "equalSign", "_dino_xml_scanner_8h.html#a822fe23411206276c7065c10a6689b6ca6d1f0bb601b497c768f006177b782bff", null ],
      [ "identifier", "_dino_xml_scanner_8h.html#a822fe23411206276c7065c10a6689b6cabc5910090fa3a645dad67c17fc5d4278", null ],
      [ "attributeValue", "_dino_xml_scanner_8h.html#a822fe23411206276c7065c10a6689b6cae6d0b5dd9bf6b12473f6b0c385cd4e56", null ],
      [ "quotedValue", "_dino_xml_scanner_8h.html#a822fe23411206276c7065c10a6689b6ca476f9b42fee48ed9d7abfed3b603634e", null ],
      [ "endOfFile", "_dino_xml_scanner_8h.html#a822fe23411206276c7065c10a6689b6cabaca55a3d517ebfd535ae54afc689d64", null ],
      [ "invalidToken", "_dino_xml_scanner_8h.html#a822fe23411206276c7065c10a6689b6ca70f5a62fd7a8b628b796af8a87024b66", null ],
      [ "noToken", "_dino_xml_scanner_8h.html#a822fe23411206276c7065c10a6689b6ca6f18c1c390af96ba6da01a5b73aef6de", null ]
    ] ]
];