var _cluster_graph_copy_attributes_8h =
[
    [ "ClusterGraphCopyAttributes", "classogdf_1_1_cluster_graph_copy_attributes.html", "classogdf_1_1_cluster_graph_copy_attributes" ],
    [ "OGDF_A_CLUSTER_GRAPH_COPY_H", "_cluster_graph_copy_attributes_8h.html#a58f6d597977ce0118a0a7793dc5f5c79", null ]
];