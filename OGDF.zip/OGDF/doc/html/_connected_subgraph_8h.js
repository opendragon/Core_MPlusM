var _connected_subgraph_8h =
[
    [ "ConnectedSubgraph", "classogdf_1_1_connected_subgraph.html", "classogdf_1_1_connected_subgraph" ],
    [ "OGDF_CONNECTED_SUBGRAPH_h", "_connected_subgraph_8h.html#a76e1d9bd7f1c092038304572083e69a0", null ]
];