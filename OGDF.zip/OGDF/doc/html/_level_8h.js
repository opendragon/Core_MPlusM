var _level_8h =
[
    [ "Level", "classogdf_1_1_level.html", "classogdf_1_1_level" ],
    [ "WeightComparer", "classogdf_1_1_weight_comparer.html", "classogdf_1_1_weight_comparer" ],
    [ "OGDF_LEVEL_H", "_level_8h.html#a360fcc4a2fa7cf82292837cdc17752b4", null ]
];