var _edge_cover_merger_8h =
[
    [ "EdgeCoverMerger", "classogdf_1_1_edge_cover_merger.html", "classogdf_1_1_edge_cover_merger" ],
    [ "OGDF_EDGE_COVER_MERGER_H", "_edge_cover_merger_8h.html#a40a4e758965b1711eec90c507807b537", null ]
];