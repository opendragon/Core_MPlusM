var _bounded_stack_8h =
[
    [ "BoundedStack", "classogdf_1_1_bounded_stack.html", "classogdf_1_1_bounded_stack" ],
    [ "BoundedStack", "classogdf_1_1_bounded_stack.html", "classogdf_1_1_bounded_stack" ],
    [ "OGDF_B_STACK_H", "_bounded_stack_8h.html#abf442e77e8b9c7452a1dc405e2bc12a2", null ],
    [ "operator<<", "_bounded_stack_8h.html#a422a366a9833db3f786a869c83a8705d", null ],
    [ "print", "_bounded_stack_8h.html#ac610208500398b214cce0552752a63ce", null ]
];