var _embedder_min_depth_max_face_8h =
[
    [ "EmbedderMinDepthMaxFace", "classogdf_1_1_embedder_min_depth_max_face.html", "classogdf_1_1_embedder_min_depth_max_face" ],
    [ "OGDF_EMBEDDER_MIN_DEPTH_MAX_FACE_H", "_embedder_min_depth_max_face_8h.html#ac772eb0ed74f269655ea7ff27d9c8a99", null ]
];