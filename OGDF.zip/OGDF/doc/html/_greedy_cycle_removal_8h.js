var _greedy_cycle_removal_8h =
[
    [ "GreedyCycleRemoval", "classogdf_1_1_greedy_cycle_removal.html", "classogdf_1_1_greedy_cycle_removal" ],
    [ "OGDF_GREEDY_CYCLE_REMOVAL_H", "_greedy_cycle_removal_8h.html#aa9cb99b670684b997f32a60b915742ad", null ]
];