var _biconnected_shelling_order_8h =
[
    [ "BiconnectedShellingOrder", "classogdf_1_1_biconnected_shelling_order.html", "classogdf_1_1_biconnected_shelling_order" ],
    [ "OGDF_BICONNECTED_SHELLING_ORDER_H", "_biconnected_shelling_order_8h.html#a43c3e5a6eabf2e14f47f4c71ecd21f73", null ]
];