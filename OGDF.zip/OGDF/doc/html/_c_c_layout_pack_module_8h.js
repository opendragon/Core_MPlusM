var _c_c_layout_pack_module_8h =
[
    [ "CCLayoutPackModule", "classogdf_1_1_c_c_layout_pack_module.html", "classogdf_1_1_c_c_layout_pack_module" ],
    [ "OGDF_CC_LAYOUT_PACK_MODULE_H", "_c_c_layout_pack_module_8h.html#a7b7eb54f9694225d2cc8989fb2b27193", null ]
];