var _l_p_solver__coin_8h =
[
    [ "LPSolver", "classogdf_1_1_l_p_solver.html", "classogdf_1_1_l_p_solver" ],
    [ "OGDF_LPSOLVER_COIN_H", "_l_p_solver__coin_8h.html#a85fb2dadbc4f3d69e3c7e19b3b25b511", null ]
];