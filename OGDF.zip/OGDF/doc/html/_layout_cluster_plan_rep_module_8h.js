var _layout_cluster_plan_rep_module_8h =
[
    [ "LayoutClusterPlanRepModule", "classogdf_1_1_layout_cluster_plan_rep_module.html", "classogdf_1_1_layout_cluster_plan_rep_module" ],
    [ "OGDF_LAYOUT_CLUSTER_PLAN_REP_MODULE_H", "_layout_cluster_plan_rep_module_8h.html#a741139cfa984ae767fb58b26d87fb2ec", null ]
];