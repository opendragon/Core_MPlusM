var _balloon_layout_8h =
[
    [ "BalloonLayout", "classogdf_1_1_balloon_layout.html", "classogdf_1_1_balloon_layout" ],
    [ "OGDF_BALLOON_LAYOUT_H_", "_balloon_layout_8h.html#ac6b0352b5c4651849522ef7b35fbbbc7", null ]
];