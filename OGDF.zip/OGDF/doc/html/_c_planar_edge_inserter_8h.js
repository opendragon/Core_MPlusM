var _c_planar_edge_inserter_8h =
[
    [ "CPlanarEdgeInserter", "classogdf_1_1_c_planar_edge_inserter.html", "classogdf_1_1_c_planar_edge_inserter" ],
    [ "NodePair", "classogdf_1_1_node_pair.html", "classogdf_1_1_node_pair" ],
    [ "OGDF_CPLANAR_EDGE_INSERTER_H", "_c_planar_edge_inserter_8h.html#a103833e86054024a9bddbcc671324d71", null ]
];