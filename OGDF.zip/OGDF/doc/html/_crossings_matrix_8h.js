var _crossings_matrix_8h =
[
    [ "CrossingsMatrix", "classogdf_1_1_crossings_matrix.html", "classogdf_1_1_crossings_matrix" ],
    [ "OGDF_CROSSINGS_MATRIX_H", "_crossings_matrix_8h.html#a414a88643f24d11827f64925db6f355f", null ]
];