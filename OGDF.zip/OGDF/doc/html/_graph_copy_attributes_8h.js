var _graph_copy_attributes_8h =
[
    [ "GraphCopyAttributes", "classogdf_1_1_graph_copy_attributes.html", "classogdf_1_1_graph_copy_attributes" ],
    [ "OGDF_A_GRAPH_COPY_H", "_graph_copy_attributes_8h.html#affeecc32bd9a42022ee8d66adf1a09eb", null ]
];