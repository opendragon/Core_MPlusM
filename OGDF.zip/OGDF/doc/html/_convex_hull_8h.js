var _convex_hull_8h =
[
    [ "ConvexHull", "classogdf_1_1_convex_hull.html", "classogdf_1_1_convex_hull" ],
    [ "OGDF_CONVEX_HULL_H", "_convex_hull_8h.html#aa4e3dc83a53862fe5ed3e3f7942e56d3", null ]
];