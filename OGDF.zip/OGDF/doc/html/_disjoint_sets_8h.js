var _disjoint_sets_8h =
[
    [ "AnyOption", "structogdf_1_1_any_option.html", null ],
    [ "CompressionOption", "structogdf_1_1_compression_option.html", null ],
    [ "DisjointSets", "classogdf_1_1_disjoint_sets.html", "classogdf_1_1_disjoint_sets" ],
    [ "InterleavingOption", "structogdf_1_1_interleaving_option.html", null ],
    [ "LinkOption", "structogdf_1_1_link_option.html", null ],
    [ "INTERMEDIATE_PARENT_CHECK", "_disjoint_sets_8h.html#af0234c3670db32ed977540d236e9f46d", null ],
    [ "CompressionOptions", "_disjoint_sets_8h.html#af2b1574f967cc28f16e6d7cce2e71b2b", [
      [ "PC", "_disjoint_sets_8h.html#af2b1574f967cc28f16e6d7cce2e71b2babff1ff014457ac733864b4cc05173266", null ],
      [ "PS", "_disjoint_sets_8h.html#af2b1574f967cc28f16e6d7cce2e71b2bad9c5a5ad71aa0e8db1a7faa4a8e8dd9a", null ],
      [ "PH", "_disjoint_sets_8h.html#af2b1574f967cc28f16e6d7cce2e71b2ba5c522d7dad142a2c82dd1a2aa1c2c354", null ],
      [ "R1", "_disjoint_sets_8h.html#af2b1574f967cc28f16e6d7cce2e71b2ba36224e8de18c86981173aefcc381e8ee", null ],
      [ "CO", "_disjoint_sets_8h.html#af2b1574f967cc28f16e6d7cce2e71b2ba85fed6410aa0559680043146dc36cac2", null ],
      [ "NF", "_disjoint_sets_8h.html#af2b1574f967cc28f16e6d7cce2e71b2bafc4b9f8d243a0754e89ca40680a75be3", null ]
    ] ],
    [ "InterleavingOptions", "_disjoint_sets_8h.html#ae22cbc46729511339f3e690bddd0fb4d", [
      [ "NI", "_disjoint_sets_8h.html#ae22cbc46729511339f3e690bddd0fb4da8a392c60962d296803ae8aaa5c48b604", null ],
      [ "Rem", "_disjoint_sets_8h.html#ae22cbc46729511339f3e690bddd0fb4dab0f281f6a3779879af153a2a378aac5a", null ],
      [ "TvL", "_disjoint_sets_8h.html#ae22cbc46729511339f3e690bddd0fb4dabf68d8964b26c70fb405a6bc223e381a", null ],
      [ "IR0", "_disjoint_sets_8h.html#ae22cbc46729511339f3e690bddd0fb4da1166962f26afd5f6c933312ce61ccef4", null ],
      [ "IPSPC", "_disjoint_sets_8h.html#ae22cbc46729511339f3e690bddd0fb4da737bd4fee3e7fd36e2b92ad8b00cd5f4", null ]
    ] ],
    [ "LinkOptions", "_disjoint_sets_8h.html#ab4616d9d77bcdaf4ea389abb532e801e", [
      [ "NL", "_disjoint_sets_8h.html#ab4616d9d77bcdaf4ea389abb532e801ead91493c4fae64f289efdd4724d01dc35", null ],
      [ "LI", "_disjoint_sets_8h.html#ab4616d9d77bcdaf4ea389abb532e801ea74af99e8e0b2eab388da9f97a49fbb40", null ],
      [ "LS", "_disjoint_sets_8h.html#ab4616d9d77bcdaf4ea389abb532e801ea6ee8622603ad1c371c579e04f8cafa27", null ],
      [ "LR", "_disjoint_sets_8h.html#ab4616d9d77bcdaf4ea389abb532e801ea12c8c909f318c5108eea06c47135a74c", null ]
    ] ],
    [ "compressionOptionNames", "_disjoint_sets_8h.html#a2eb15d30a53d87a0afb206e4cbe7a4a1", null ],
    [ "interleavingOptionNames", "_disjoint_sets_8h.html#a5437381d96bdb129f0ab0f7105d1f157", null ],
    [ "linkOptionNames", "_disjoint_sets_8h.html#aa3cf0e42ca2607be91e91b3087a70738", null ]
];