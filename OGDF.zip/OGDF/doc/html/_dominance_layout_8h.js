var _dominance_layout_8h =
[
    [ "DominanceLayout", "classogdf_1_1_dominance_layout.html", "classogdf_1_1_dominance_layout" ],
    [ "OGDF_DOMINANCE_LAYOUT_H", "_dominance_layout_8h.html#a5fabb3adee59567fc0b987848ff4482a", null ]
];