var _dynamic_b_c_tree_8h =
[
    [ "DynamicBCTree", "classogdf_1_1_dynamic_b_c_tree.html", "classogdf_1_1_dynamic_b_c_tree" ],
    [ "OGDF_DYNAMIC_BC_TREE_H", "_dynamic_b_c_tree_8h.html#aad3fd3a179ed71771ecd31ffa197c356", null ]
];