var _cluster_planarization_layout_8h =
[
    [ "ClusterPlanarizationLayout", "classogdf_1_1_cluster_planarization_layout.html", "classogdf_1_1_cluster_planarization_layout" ],
    [ "ClusterPosition", "structogdf_1_1_cluster_planarization_layout_1_1_cluster_position.html", "structogdf_1_1_cluster_planarization_layout_1_1_cluster_position" ],
    [ "OGDF_CLUSTER_PLANARIZATION_LAYOUT_H", "_cluster_planarization_layout_8h.html#a69fc7aac473d78a74d01d31156a1387b", null ]
];