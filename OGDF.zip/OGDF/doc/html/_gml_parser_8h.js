var _gml_parser_8h =
[
    [ "GmlObject", "structogdf_1_1_gml_object.html", "structogdf_1_1_gml_object" ],
    [ "GmlParser", "classogdf_1_1_gml_parser.html", "classogdf_1_1_gml_parser" ],
    [ "OGDF_GML_PARSER_H", "_gml_parser_8h.html#a202c309782c2e3ccbdc45c368a460386", null ],
    [ "GmlKey", "_gml_parser_8h.html#ab78b4a76e5f947017e1cd6e60b4be1c7", null ],
    [ "GmlObjectType", "_gml_parser_8h.html#a13e68833971aca99db78ac2d5f502428", [
      [ "gmlIntValue", "_gml_parser_8h.html#a13e68833971aca99db78ac2d5f502428a96271babe3e09dd197dea3ea1706326f", null ],
      [ "gmlDoubleValue", "_gml_parser_8h.html#a13e68833971aca99db78ac2d5f502428ab7ae245ff0c0375bb5e1b1d7bc79af2e", null ],
      [ "gmlStringValue", "_gml_parser_8h.html#a13e68833971aca99db78ac2d5f502428ab5dc7d42a2c3c4ec284ae304efc37994", null ],
      [ "gmlListBegin", "_gml_parser_8h.html#a13e68833971aca99db78ac2d5f502428ad86447f502f2ac91a955dc3e3f7c9be1", null ],
      [ "gmlListEnd", "_gml_parser_8h.html#a13e68833971aca99db78ac2d5f502428a3e2d37726523f90951aebf23ae72cb1b", null ],
      [ "gmlKey", "_gml_parser_8h.html#a13e68833971aca99db78ac2d5f502428ae4dadf43c0c5b705873e67e76c6f6e73", null ],
      [ "gmlEOF", "_gml_parser_8h.html#a13e68833971aca99db78ac2d5f502428a65851ccc44d28b116b1b017d980ef42e", null ],
      [ "gmlError", "_gml_parser_8h.html#a13e68833971aca99db78ac2d5f502428a8cb6650ac092838f5dff61374bf98f6b", null ]
    ] ]
];