var _embedder_min_depth_8h =
[
    [ "EmbedderMinDepth", "classogdf_1_1_embedder_min_depth.html", "classogdf_1_1_embedder_min_depth" ],
    [ "OGDF_EMBEDDER_MIN_DEPTH_H", "_embedder_min_depth_8h.html#a2f6ce8604010c99a84fd3d2f9f930bf3", null ]
];