var _boyer_myrvold_init_8h =
[
    [ "BoyerMyrvoldInit", "classogdf_1_1_boyer_myrvold_init.html", "classogdf_1_1_boyer_myrvold_init" ],
    [ "BucketLowPoint", "classogdf_1_1_bucket_low_point.html", "classogdf_1_1_bucket_low_point" ],
    [ "OGDF_BOYER_MYRVOLD_INIT_H", "_boyer_myrvold_init_8h.html#a2c37012288ce715566f82a232565af52", null ]
];