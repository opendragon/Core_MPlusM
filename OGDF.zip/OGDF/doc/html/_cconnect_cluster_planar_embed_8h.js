var _cconnect_cluster_planar_embed_8h =
[
    [ "CconnectClusterPlanarEmbed", "classogdf_1_1_cconnect_cluster_planar_embed.html", "classogdf_1_1_cconnect_cluster_planar_embed" ],
    [ "OGDF_CCONNECT_CLUSTER_PLANAR_EMBED_H", "_cconnect_cluster_planar_embed_8h.html#add462231521773021637b63872aaff03", null ]
];