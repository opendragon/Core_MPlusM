var _critical_section_8h =
[
    [ "CriticalSection", "classogdf_1_1_critical_section.html", "classogdf_1_1_critical_section" ],
    [ "OGDF_CRITICAL_SECTION_H", "_critical_section_8h.html#a80f152b9832afe859242ac926cdfc1be", null ]
];