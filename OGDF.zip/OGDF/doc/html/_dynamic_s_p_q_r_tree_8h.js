var _dynamic_s_p_q_r_tree_8h =
[
    [ "DynamicSPQRTree", "classogdf_1_1_dynamic_s_p_q_r_tree.html", "classogdf_1_1_dynamic_s_p_q_r_tree" ],
    [ "OGDF_DYNAMIC_SPQR_TREE_H", "_dynamic_s_p_q_r_tree_8h.html#ac97eb99078cd30dd42e9423c2d7982bc", null ]
];