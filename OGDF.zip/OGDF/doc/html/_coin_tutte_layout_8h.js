var _coin_tutte_layout_8h =
[
    [ "TutteLayout", "classogdf_1_1_tutte_layout.html", "classogdf_1_1_tutte_layout" ],
    [ "OGDF_TUTTE_LAYOUT_H", "_coin_tutte_layout_8h.html#acb499aea236a221d14cb183c49c88193", null ]
];