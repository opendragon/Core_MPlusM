var _adjacency_oracle_8h =
[
    [ "AdjacencyOracle", "classogdf_1_1_adjacency_oracle.html", "classogdf_1_1_adjacency_oracle" ],
    [ "OGDF_ADJACENCY_ORACLE_H", "_adjacency_oracle_8h.html#aec4637d5230c19d95790513d45607a2e", null ]
];