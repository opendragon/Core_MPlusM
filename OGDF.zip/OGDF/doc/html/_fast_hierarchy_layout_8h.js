var _fast_hierarchy_layout_8h =
[
    [ "FastHierarchyLayout", "classogdf_1_1_fast_hierarchy_layout.html", "classogdf_1_1_fast_hierarchy_layout" ],
    [ "OGDF_FAST_HIERARCHY_LAYOUT_H", "_fast_hierarchy_layout_8h.html#a118a82faef3b8b06f129a13968effa79", null ]
];