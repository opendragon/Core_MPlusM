var _coffman_graham_ranking_8h =
[
    [ "CoffmanGrahamRanking", "classogdf_1_1_coffman_graham_ranking.html", "classogdf_1_1_coffman_graham_ranking" ],
    [ "_int_set", "classogdf_1_1_coffman_graham_ranking_1_1__int__set.html", "classogdf_1_1_coffman_graham_ranking_1_1__int__set" ],
    [ "OGDF_COFFMAN_GRAHAM_RANKING_H", "_coffman_graham_ranking_8h.html#aa42acd34d6c3a00d50b8fb53805f9e87", null ]
];