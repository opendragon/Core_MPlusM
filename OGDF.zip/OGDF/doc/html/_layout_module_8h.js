var _layout_module_8h =
[
    [ "LayoutModule", "classogdf_1_1_layout_module.html", "classogdf_1_1_layout_module" ],
    [ "OGDF_LAYOUT_MODULE_H", "_layout_module_8h.html#aac0a2a0cabca2be9a5f5729d7735d6cb", null ]
];