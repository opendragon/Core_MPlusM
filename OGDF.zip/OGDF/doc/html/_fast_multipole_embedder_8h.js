var _fast_multipole_embedder_8h =
[
    [ "FastMultipoleEmbedder", "classogdf_1_1_fast_multipole_embedder.html", "classogdf_1_1_fast_multipole_embedder" ],
    [ "FastMultipoleMultilevelEmbedder", "classogdf_1_1_fast_multipole_multilevel_embedder.html", "classogdf_1_1_fast_multipole_multilevel_embedder" ],
    [ "OGDF_FAST_MULTIPOLE_EMBEDDER_H", "_fast_multipole_embedder_8h.html#a0337330b6e296aeac77a4cda0deac9de", null ]
];