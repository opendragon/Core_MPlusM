var _barycenter_heuristic_8h =
[
    [ "BarycenterHeuristic", "classogdf_1_1_barycenter_heuristic.html", "classogdf_1_1_barycenter_heuristic" ],
    [ "OGDF_BARYCENTER_HEURISTIC_H", "_barycenter_heuristic_8h.html#adef2f0b104590f3db60bd43660404e16", null ]
];