var _initial_placer_8h =
[
    [ "InitialPlacer", "classogdf_1_1_initial_placer.html", "classogdf_1_1_initial_placer" ],
    [ "OGDF_INITIAL_PLACER_H", "_initial_placer_8h.html#a0d007e0f8326276420601252142a443f", null ]
];