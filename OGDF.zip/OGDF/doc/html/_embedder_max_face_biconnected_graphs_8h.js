var _embedder_max_face_biconnected_graphs_8h =
[
    [ "EmbedderMaxFaceBiconnectedGraphs", "classogdf_1_1_embedder_max_face_biconnected_graphs.html", "classogdf_1_1_embedder_max_face_biconnected_graphs" ],
    [ "OGDF_EMBEDDER_MAX_FACE_BICONNECTED_GRAPHS_H", "_embedder_max_face_biconnected_graphs_8h.html#a5cebed2aa615a96b2be64d850da5321c", null ]
];