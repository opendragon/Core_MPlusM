var _booth_lueker_8h =
[
    [ "BoothLueker", "classogdf_1_1_booth_lueker.html", "classogdf_1_1_booth_lueker" ],
    [ "OGDF_BOOTH_LUEKER_H", "_booth_lueker_8h.html#abd568b942484bd13ba2845f2987c5b05", null ]
];