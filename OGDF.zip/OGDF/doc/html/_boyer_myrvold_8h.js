var _boyer_myrvold_8h =
[
    [ "BoyerMyrvold", "classogdf_1_1_boyer_myrvold.html", "classogdf_1_1_boyer_myrvold" ],
    [ "OGDF_BOYER_MYRVOLD_H", "_boyer_myrvold_8h.html#a15c0a34329676e06db8ed2b025259425", null ]
];