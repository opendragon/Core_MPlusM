var _cluster_graph_observer_8h =
[
    [ "ClusterGraphObserver", "classogdf_1_1_cluster_graph_observer.html", "classogdf_1_1_cluster_graph_observer" ],
    [ "OGDF_CLUSTER_GRAPH_OBSERVER_H", "_cluster_graph_observer_8h.html#ab7a4e7d7e4c04c9521fdd9b7a328c1ca", null ]
];