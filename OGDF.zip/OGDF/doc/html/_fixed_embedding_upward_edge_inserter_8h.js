var _fixed_embedding_upward_edge_inserter_8h =
[
    [ "FixedEmbeddingUpwardEdgeInserter", "classogdf_1_1_fixed_embedding_upward_edge_inserter.html", "classogdf_1_1_fixed_embedding_upward_edge_inserter" ],
    [ "OGDF_FIXED_EMBEDDING_UPWARD_EDGE_INSERTER_H", "_fixed_embedding_upward_edge_inserter_8h.html#ad88f6889fac0377e5e68a4fca64a8848", null ]
];