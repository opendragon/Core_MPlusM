var _barycenter_placer_8h =
[
    [ "BarycenterPlacer", "classogdf_1_1_barycenter_placer.html", "classogdf_1_1_barycenter_placer" ],
    [ "OGDF_BARYCENTER_PLACER_H", "_barycenter_placer_8h.html#a6b0a05ac84887b47e42d1fc62495654f", null ]
];