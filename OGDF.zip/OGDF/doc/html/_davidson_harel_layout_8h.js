var _davidson_harel_layout_8h =
[
    [ "DavidsonHarelLayout", "classogdf_1_1_davidson_harel_layout.html", "classogdf_1_1_davidson_harel_layout" ],
    [ "OGDF_DAVIDSON_HAREL_LAYOUT_H", "_davidson_harel_layout_8h.html#ab3fac912be33ec962d8f33feb3f61a49", null ]
];