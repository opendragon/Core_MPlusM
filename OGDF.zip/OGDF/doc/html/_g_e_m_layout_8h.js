var _g_e_m_layout_8h =
[
    [ "GEMLayout", "classogdf_1_1_g_e_m_layout.html", "classogdf_1_1_g_e_m_layout" ],
    [ "OGDF_FAST_LAYOUT_H", "_g_e_m_layout_8h.html#a8c3dd7768a9e167d7df3df522e0b0b00", null ]
];