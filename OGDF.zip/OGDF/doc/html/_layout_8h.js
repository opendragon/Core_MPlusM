var _layout_8h =
[
    [ "Layout", "classogdf_1_1_layout.html", "classogdf_1_1_layout" ],
    [ "OGDF_LAYOUT_H", "_layout_8h.html#a2bb176c656a699d02874b2e2fa7df8c1", null ]
];