var _boyer_myrvold_planar_8h =
[
    [ "BoyerMyrvoldPlanar", "classogdf_1_1_boyer_myrvold_planar.html", "classogdf_1_1_boyer_myrvold_planar" ],
    [ "OGDF_BOYER_MYRVOLD_PLANAR_H", "_boyer_myrvold_planar_8h.html#ae481733475825c842cd29126afbcb615", null ],
    [ "enumDirection", "_boyer_myrvold_planar_8h.html#a4b216693fd93da9ed00497c9f795c79a", [
      [ "CCW", "_boyer_myrvold_planar_8h.html#a4b216693fd93da9ed00497c9f795c79aae7bf42e57859ea732889c78228cb960f", null ],
      [ "CW", "_boyer_myrvold_planar_8h.html#a4b216693fd93da9ed00497c9f795c79aa668ae5437fe32013130a6310eaae15be", null ]
    ] ],
    [ "enumEdgeType", "_boyer_myrvold_planar_8h.html#a0f9e7ce5df7d39b37cae28fa4783d71e", [
      [ "EDGE_UNDEFINED", "_boyer_myrvold_planar_8h.html#a0f9e7ce5df7d39b37cae28fa4783d71eae8ab991502569243c8a2c55479d08c90", null ],
      [ "EDGE_SELFLOOP", "_boyer_myrvold_planar_8h.html#a0f9e7ce5df7d39b37cae28fa4783d71eac3a2c4196e7564c07c6408bf54427a94", null ],
      [ "EDGE_BACK", "_boyer_myrvold_planar_8h.html#a0f9e7ce5df7d39b37cae28fa4783d71eabaf1cb0d39de7a2eb3927c709b386b5f", null ],
      [ "EDGE_DFS", "_boyer_myrvold_planar_8h.html#a0f9e7ce5df7d39b37cae28fa4783d71ea36af3cc8498e1874f0dbe87a7ba07093", null ],
      [ "EDGE_DFS_PARALLEL", "_boyer_myrvold_planar_8h.html#a0f9e7ce5df7d39b37cae28fa4783d71ea3736282cade7d4d0ce4cb67a61d51455", null ],
      [ "EDGE_BACK_DELETED", "_boyer_myrvold_planar_8h.html#a0f9e7ce5df7d39b37cae28fa4783d71ea7f46c3620545f56b30b233837024c4c8", null ]
    ] ]
];