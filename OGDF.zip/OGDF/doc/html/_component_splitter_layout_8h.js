var _component_splitter_layout_8h =
[
    [ "ComponentSplitterLayout", "classogdf_1_1_component_splitter_layout.html", "classogdf_1_1_component_splitter_layout" ],
    [ "OGDF_COMPONENT_SPLITTER_LAYOUT_H", "_component_splitter_layout_8h.html#a6b1b9411c1462d93a6acb727576f0b16", null ]
];