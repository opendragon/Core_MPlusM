var _kuratowski_subdivision_8h =
[
    [ "KuratowskiSubdivision", "classogdf_1_1_kuratowski_subdivision.html", null ],
    [ "OGDF_KURATOWSKI_SUBDIVISION_H", "_kuratowski_subdivision_8h.html#a0e1abe22a79f323e3e75f240649b83c4", null ]
];