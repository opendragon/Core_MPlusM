var _dynamic_s_p_q_r_forest_8h =
[
    [ "DynamicSPQRForest", "classogdf_1_1_dynamic_s_p_q_r_forest.html", "classogdf_1_1_dynamic_s_p_q_r_forest" ],
    [ "OGDF_DYNAMIC_SPQR_FOREST_H", "_dynamic_s_p_q_r_forest_8h.html#ad63844952e7e2dfeb0ef9984be61917d", null ]
];