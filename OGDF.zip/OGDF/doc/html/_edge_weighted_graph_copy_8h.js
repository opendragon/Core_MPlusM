var _edge_weighted_graph_copy_8h =
[
    [ "EdgeWeightedGraphCopy", "classogdf_1_1_edge_weighted_graph_copy.html", "classogdf_1_1_edge_weighted_graph_copy" ],
    [ "OGDF_EDGE_WEIGHTED_GRAPH_COPY_H_", "_edge_weighted_graph_copy_8h.html#a856df64cd755c5de81ff9a82e2b1e6b0", null ]
];