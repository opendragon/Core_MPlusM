var _edge_label_8h =
[
    [ "ELabelPos", "classogdf_1_1_e_label_pos.html", "classogdf_1_1_e_label_pos" ],
    [ "FeatureComparer", "classogdf_1_1_e_label_pos_1_1_feature_comparer.html", "classogdf_1_1_e_label_pos_1_1_feature_comparer" ],
    [ "FeatureInfo", "structogdf_1_1_e_label_pos_1_1_feature_info.html", "structogdf_1_1_e_label_pos_1_1_feature_info" ],
    [ "FeatureLink", "structogdf_1_1_e_label_pos_1_1_feature_link.html", "structogdf_1_1_e_label_pos_1_1_feature_link" ],
    [ "LabelInfo", "structogdf_1_1_e_label_pos_1_1_label_info.html", "structogdf_1_1_e_label_pos_1_1_label_info" ],
    [ "PosInfo", "structogdf_1_1_e_label_pos_1_1_pos_info.html", "structogdf_1_1_e_label_pos_1_1_pos_info" ],
    [ "SegmentInfo", "structogdf_1_1_e_label_pos_1_1_segment_info.html", "structogdf_1_1_e_label_pos_1_1_segment_info" ],
    [ "OGDF_EDGE_LABEL_H", "_edge_label_8h.html#a60450d6fe2ef527b1e28ca7386a1bc0a", null ],
    [ "candStatus", "_edge_label_8h.html#a1106fbccc0fb9a11e33442be3140f66e", [
      [ "csAssigned", "_edge_label_8h.html#a1106fbccc0fb9a11e33442be3140f66ea5b2ea908e742d2e4340bf7d179cc8d3b", null ],
      [ "csFIntersect", "_edge_label_8h.html#a1106fbccc0fb9a11e33442be3140f66eaaf97cc05dcdee4b92cfc8be3683928c8", null ],
      [ "csActive", "_edge_label_8h.html#a1106fbccc0fb9a11e33442be3140f66eab146837b48f1adbc37098a887b84e0dc", null ],
      [ "csUsed", "_edge_label_8h.html#a1106fbccc0fb9a11e33442be3140f66ea32b96dec90c9f7a94668a2cd1c9fe360", null ]
    ] ],
    [ "OutputParameter", "_edge_label_8h.html#a6dc5527490663c8074638e3a0388739d", [
      [ "opStandard", "_edge_label_8h.html#a6dc5527490663c8074638e3a0388739da35933a17c58e88413b819f6b2c0b94c9", null ],
      [ "opOmitIntersect", "_edge_label_8h.html#a6dc5527490663c8074638e3a0388739da65c6e3b8c3652e0920b61d32739a56ee", null ],
      [ "opOmitFIntersect", "_edge_label_8h.html#a6dc5527490663c8074638e3a0388739da5d70ece7c792f113d98b179cc9b37066", null ],
      [ "opResult", "_edge_label_8h.html#a6dc5527490663c8074638e3a0388739dacb9d767aa21290c0124908b3f6be36ac", null ]
    ] ]
];