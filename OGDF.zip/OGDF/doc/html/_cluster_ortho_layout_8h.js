var _cluster_ortho_layout_8h =
[
    [ "ClusterOrthoLayout", "classogdf_1_1_cluster_ortho_layout.html", "classogdf_1_1_cluster_ortho_layout" ],
    [ "OGDF_CLUSTER_ORTHO_LAYOUT_H", "_cluster_ortho_layout_8h.html#a4b14443842c9cd78ac89f04554fbb161", null ]
];