var _ind_info_8h =
[
    [ "IndInfo", "classogdf_1_1_ind_info.html", "classogdf_1_1_ind_info" ],
    [ "OGDF_EMBED_KEY_H", "_ind_info_8h.html#a477faccac4e07bbe961bc75faf98810a", null ]
];