var _dual_graph_8h =
[
    [ "DualGraph", "classogdf_1_1_dual_graph.html", "classogdf_1_1_dual_graph" ],
    [ "OGDF_DUAL_GRAPH_H", "_dual_graph_8h.html#a3131be6ae0017d44acf8aa085e0a5188", null ]
];