var _independent_set_merger_8h =
[
    [ "IndependentSetMerger", "classogdf_1_1_independent_set_merger.html", "classogdf_1_1_independent_set_merger" ],
    [ "OGDF_INDEPENDENT_SET_MERGER_H", "_independent_set_merger_8h.html#a6e637144ae7d0d08b4422b56ec8118d3", null ]
];