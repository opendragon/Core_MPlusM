var _layer_based_u_p_r_layout_8h =
[
    [ "LayerBasedUPRLayout", "classogdf_1_1_layer_based_u_p_r_layout.html", "classogdf_1_1_layer_based_u_p_r_layout" ],
    [ "RankComparer", "structogdf_1_1_layer_based_u_p_r_layout_1_1_rank_comparer.html", "structogdf_1_1_layer_based_u_p_r_layout_1_1_rank_comparer" ],
    [ "OrderComparer", "classogdf_1_1_order_comparer.html", "classogdf_1_1_order_comparer" ],
    [ "OGDF_LAYER_BASED_UPR_LAYOUT_H", "_layer_based_u_p_r_layout_8h.html#a6216fbb0182ff7ad4a1b50f97a49a181", null ]
];