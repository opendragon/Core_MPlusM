var _fixed_upward_embedding_inserter_8h =
[
    [ "FixedUpwardEmbeddingInserter", "classogdf_1_1_fixed_upward_embedding_inserter.html", "classogdf_1_1_fixed_upward_embedding_inserter" ],
    [ "OGDF_FIXED_UPWARD_EMBEDDING_INSERTER_H", "_fixed_upward_embedding_inserter_8h.html#aa2c12f5cd39e1bed1a592bc14a446389", null ]
];