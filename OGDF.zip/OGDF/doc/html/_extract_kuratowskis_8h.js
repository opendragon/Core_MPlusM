var _extract_kuratowskis_8h =
[
    [ "DynamicBacktrack", "classogdf_1_1_dynamic_backtrack.html", "classogdf_1_1_dynamic_backtrack" ],
    [ "ExtractKuratowskis", "classogdf_1_1_extract_kuratowskis.html", "classogdf_1_1_extract_kuratowskis" ],
    [ "KuratowskiWrapper", "classogdf_1_1_kuratowski_wrapper.html", "classogdf_1_1_kuratowski_wrapper" ],
    [ "OGDF_EXTRACT_KURATOWSKIS_H", "_extract_kuratowskis_8h.html#a74cfc0f61c9201361bec547d168c2ce7", null ]
];