var _fixed_embedding_inserter_8h =
[
    [ "FaceArray", "class_face_array.html", null ],
    [ "FixedEmbeddingInserter", "classogdf_1_1_fixed_embedding_inserter.html", "classogdf_1_1_fixed_embedding_inserter" ],
    [ "OGDF_FIXED_EMBEDDING_INSERTER_H", "_fixed_embedding_inserter_8h.html#add4ed11e2bfb3a2abb1e1b61de5c4c0e", null ]
];