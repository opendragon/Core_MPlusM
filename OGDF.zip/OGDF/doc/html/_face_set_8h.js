var _face_set_8h =
[
    [ "FaceSet", "classogdf_1_1_face_set.html", "classogdf_1_1_face_set" ],
    [ "FaceSetPure", "classogdf_1_1_face_set_pure.html", "classogdf_1_1_face_set_pure" ],
    [ "FaceSetSimple", "classogdf_1_1_face_set_simple.html", "classogdf_1_1_face_set_simple" ],
    [ "OGDF_FACE_SET_H", "_face_set_8h.html#a503f31e9039e443f70fca82624d84238", null ]
];