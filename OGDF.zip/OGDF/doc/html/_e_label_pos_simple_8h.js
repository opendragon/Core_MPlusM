var _e_label_pos_simple_8h =
[
    [ "ELabelPosSimple", "classogdf_1_1_e_label_pos_simple.html", "classogdf_1_1_e_label_pos_simple" ],
    [ "OGDF_E_LABEL_POS_SIMPLE_H", "_e_label_pos_simple_8h.html#a91845f58c52e2b90c48fb165a5fdebd9", null ]
];