var _dynamic_planar_s_p_q_r_tree_8h =
[
    [ "Array", "classogdf_1_1_array.html", "classogdf_1_1_array" ],
    [ "DynamicPlanarSPQRTree", "classogdf_1_1_dynamic_planar_s_p_q_r_tree.html", "classogdf_1_1_dynamic_planar_s_p_q_r_tree" ],
    [ "Tuple2", "classogdf_1_1_tuple2.html", "classogdf_1_1_tuple2" ],
    [ "OGDF_DYNAMIC_PLANAR_SPQR_TREE_H", "_dynamic_planar_s_p_q_r_tree_8h.html#a25f3dd34b4778114b0c89b5de2f603a6", null ]
];