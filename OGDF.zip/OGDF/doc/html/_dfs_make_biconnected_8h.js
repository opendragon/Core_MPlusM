var _dfs_make_biconnected_8h =
[
    [ "DfsMakeBiconnected", "classogdf_1_1_dfs_make_biconnected.html", "classogdf_1_1_dfs_make_biconnected" ],
    [ "OGDF_DFS_MAKE_BICONNECTED_H", "_dfs_make_biconnected_8h.html#a20cea4ad13bfdb271ff7b4727c6f8c60", null ]
];