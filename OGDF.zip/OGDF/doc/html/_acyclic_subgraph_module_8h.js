var _acyclic_subgraph_module_8h =
[
    [ "AcyclicSubgraphModule", "classogdf_1_1_acyclic_subgraph_module.html", "classogdf_1_1_acyclic_subgraph_module" ],
    [ "OGDF_ACYCLIC_SUBGRAPH_MODULE_H", "_acyclic_subgraph_module_8h.html#a063c26116ce1605aef41cf662f44c281", null ]
];