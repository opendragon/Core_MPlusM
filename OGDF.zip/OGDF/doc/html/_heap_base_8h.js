var _heap_base_8h =
[
    [ "HeapBase", "classogdf_1_1_heap_base.html", "classogdf_1_1_heap_base" ],
    [ "OGDF_HEAP_BASE_H", "_heap_base_8h.html#ad5bcf62c8dd257e59bd23aafd92469c2", null ]
];