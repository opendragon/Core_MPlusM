var _energy_function_8h =
[
    [ "EnergyFunction", "classogdf_1_1_energy_function.html", "classogdf_1_1_energy_function" ],
    [ "OGDF_ENERGY_FUNCTION_H", "_energy_function_8h.html#acdf9253a6b9e560b09393f011404ed38", null ]
];