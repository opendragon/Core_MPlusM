var _c_planar_sub_clustered_graph_8h =
[
    [ "CPlanarSubClusteredGraph", "classogdf_1_1_c_planar_sub_clustered_graph.html", "classogdf_1_1_c_planar_sub_clustered_graph" ],
    [ "OGDF_CPLANAR_SUBCLUSTERED_GRAPH_H", "_c_planar_sub_clustered_graph_8h.html#a6ad8f6d716ae2a3e332a29d6b279a28b", null ]
];