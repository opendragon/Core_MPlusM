var _face_array_8h =
[
    [ "FaceArray", "classogdf_1_1_face_array.html", "classogdf_1_1_face_array" ],
    [ "FaceArrayBase", "classogdf_1_1_face_array_base.html", "classogdf_1_1_face_array_base" ],
    [ "OGDF_FACE_ARRAY_H", "_face_array_8h.html#a499cd4df5abbeecfaad3d2e9dda8b0c1", null ]
];