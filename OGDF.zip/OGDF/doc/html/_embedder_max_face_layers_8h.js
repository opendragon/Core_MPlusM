var _embedder_max_face_layers_8h =
[
    [ "EmbedderMaxFaceLayers", "classogdf_1_1_embedder_max_face_layers.html", "classogdf_1_1_embedder_max_face_layers" ],
    [ "OGDF_EMBEDDER_MAX_FACE_LAYERS_H", "_embedder_max_face_layers_8h.html#a8edcfeefc5ae58551d44e5578df595a8", null ]
];