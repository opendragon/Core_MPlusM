var _davidson_harel_8h =
[
    [ "DavidsonHarel", "classogdf_1_1_davidson_harel.html", "classogdf_1_1_davidson_harel" ],
    [ "OGDF_DAVIDSON_HAREL_H", "_davidson_harel_8h.html#a835e26394259233e6f341048a6dc37df", null ]
];