var _cconnect_cluster_planar_8h =
[
    [ "CconnectClusterPlanar", "classogdf_1_1_cconnect_cluster_planar.html", "classogdf_1_1_cconnect_cluster_planar" ],
    [ "OGDF_CCONNECT_CLUSTER_PLANAR_H", "_cconnect_cluster_planar_8h.html#a5f7c24a40ad1a606ab837422992b6608", null ]
];