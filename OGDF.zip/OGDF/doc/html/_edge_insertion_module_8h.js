var _edge_insertion_module_8h =
[
    [ "EdgeInsertionModule", "classogdf_1_1_edge_insertion_module.html", "classogdf_1_1_edge_insertion_module" ],
    [ "OGDF_EDGE_INSERTION_MODULE_H", "_edge_insertion_module_8h.html#adf849fc76ce06a73c7852be464be2683", null ]
];