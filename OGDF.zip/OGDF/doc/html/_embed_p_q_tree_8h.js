var _embed_p_q_tree_8h =
[
    [ "EmbedPQTree", "classogdf_1_1_embed_p_q_tree.html", "classogdf_1_1_embed_p_q_tree" ],
    [ "OGDF_EMBED_PQTREE_H", "_embed_p_q_tree_8h.html#add03dab0b09cbeac1045b726b63ba80b", null ],
    [ "PtrPlanarLeafKeyI", "_embed_p_q_tree_8h.html#aa1ac886df9c9bfac17ae60d49ba3c419", null ],
    [ "PtrPQBasicKeyEIB", "_embed_p_q_tree_8h.html#ac1c7404aa2d1d2efecaaba48bccf8961", null ],
    [ "doDestruction< PtrPlanarLeafKeyI >", "_embed_p_q_tree_8h.html#a08346104854dae28161ede5daa807e4a", null ],
    [ "doDestruction< PtrPQBasicKeyEIB >", "_embed_p_q_tree_8h.html#aeb2195b9fe8948642c83fe0747888e55", null ]
];