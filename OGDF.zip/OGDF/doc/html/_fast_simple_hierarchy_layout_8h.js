var _fast_simple_hierarchy_layout_8h =
[
    [ "FastSimpleHierarchyLayout", "classogdf_1_1_fast_simple_hierarchy_layout.html", "classogdf_1_1_fast_simple_hierarchy_layout" ],
    [ "OGDF_FAST_SIMPLE_LAYOUT_H", "_fast_simple_hierarchy_layout_8h.html#af36a8485e64e5fd327425e5b57167399", null ]
];