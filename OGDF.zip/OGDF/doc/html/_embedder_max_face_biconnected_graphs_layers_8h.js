var _embedder_max_face_biconnected_graphs_layers_8h =
[
    [ "EmbedderMaxFaceBiconnectedGraphsLayers", "classogdf_1_1_embedder_max_face_biconnected_graphs_layers.html", "classogdf_1_1_embedder_max_face_biconnected_graphs_layers" ],
    [ "OGDF_EMBEDDER_MAX_FACE_BICONNECTED_GRAPHS_Layers_H", "_embedder_max_face_biconnected_graphs_layers_8h.html#ab4269344f712076da7534e092a180b19", null ]
];