var _c_planar_sub_clustered_s_t_8h =
[
    [ "CPlanarSubClusteredST", "classogdf_1_1_c_planar_sub_clustered_s_t.html", "classogdf_1_1_c_planar_sub_clustered_s_t" ],
    [ "OGDF_CPLANAR_SUBCLUSTERED_ST_H", "_c_planar_sub_clustered_s_t_8h.html#a2caa81fcac161c3bceef1ada08f43c5c", null ]
];