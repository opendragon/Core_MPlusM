var _force_layout_module_8h =
[
    [ "ForceLayoutModule", "classogdf_1_1_force_layout_module.html", "classogdf_1_1_force_layout_module" ],
    [ "OGDF_FORCE_LAYOUT_MODULE_H", "_force_layout_module_8h.html#a1cee6236e487c02091b78a57bfe1a2a7", null ]
];