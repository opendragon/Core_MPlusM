var _circular_layout_8h =
[
    [ "CircularLayout", "classogdf_1_1_circular_layout.html", "classogdf_1_1_circular_layout" ],
    [ "OGDF_CIRCULAR_LAYOUT_H", "_circular_layout_8h.html#a1c427f617816a0f907eb273f6984af1c", null ]
];