var _fast_planar_subgraph_8h =
[
    [ "FastPlanarSubgraph", "classogdf_1_1_fast_planar_subgraph.html", "classogdf_1_1_fast_planar_subgraph" ],
    [ "OGDF_FAST_PLANAR_SUBGRAPH_H", "_fast_planar_subgraph_8h.html#aa0a98fc185b3a162f62b982dc9321e7e", null ]
];