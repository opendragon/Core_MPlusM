var _find_kuratowskis_8h =
[
    [ "ExternE", "structogdf_1_1_extern_e.html", "structogdf_1_1_extern_e" ],
    [ "FindKuratowskis", "classogdf_1_1_find_kuratowskis.html", "classogdf_1_1_find_kuratowskis" ],
    [ "KuratowskiStructure", "classogdf_1_1_kuratowski_structure.html", "classogdf_1_1_kuratowski_structure" ],
    [ "WInfo", "structogdf_1_1_w_info.html", "structogdf_1_1_w_info" ],
    [ "OGDF_FIND_KURATOWSKIS_H", "_find_kuratowskis_8h.html#a3d4a1b9782e95e49fb7003fd6c184dd5", null ]
];