var _edge_router_8h =
[
    [ "EdgeRouter", "classogdf_1_1_edge_router.html", "classogdf_1_1_edge_router" ],
    [ "OGDF_EDGE_ROUTER_H", "_edge_router_8h.html#a48dc757a110a9f4c79458094e9f2ff05", null ],
    [ "bend_type", "_edge_router_8h.html#a0829f9b3fba19cca4733ff6e3a34453f", [
      [ "bend_free", "_edge_router_8h.html#a0829f9b3fba19cca4733ff6e3a34453fab3864514efc85e6b05db555fbe990850", null ],
      [ "bend_1left", "_edge_router_8h.html#a0829f9b3fba19cca4733ff6e3a34453fae9eb4038ce7a9138f4bc0918086b5a7a", null ],
      [ "bend_1right", "_edge_router_8h.html#a0829f9b3fba19cca4733ff6e3a34453faba2b7bba69a992decd18fe92940830c4", null ],
      [ "bend_2left", "_edge_router_8h.html#a0829f9b3fba19cca4733ff6e3a34453fae53c3ce9fbe0fb745678253f65665366", null ],
      [ "bend_2right", "_edge_router_8h.html#a0829f9b3fba19cca4733ff6e3a34453faf7269a49b87d69662f145335a2bb8841", null ],
      [ "prob_bf", "_edge_router_8h.html#a0829f9b3fba19cca4733ff6e3a34453faadc1e01fe12654a14df48a2873ba50cb", null ],
      [ "prob_b1l", "_edge_router_8h.html#a0829f9b3fba19cca4733ff6e3a34453fa98a582fa53f2e16359f64132734d737c", null ],
      [ "prob_b1r", "_edge_router_8h.html#a0829f9b3fba19cca4733ff6e3a34453fa51c1853d339ed1972d9ac39effc7a319", null ],
      [ "prob_b2l", "_edge_router_8h.html#a0829f9b3fba19cca4733ff6e3a34453fa2b7722bbd9ae4803babb36e0c185cb62", null ],
      [ "prob_b2r", "_edge_router_8h.html#a0829f9b3fba19cca4733ff6e3a34453fab9fad72ac2e043a19ec3665cc9853aba", null ]
    ] ],
    [ "process_type", "_edge_router_8h.html#abf2d63e42c92dff7424ee06eac278c60", [
      [ "unprocessed", "_edge_router_8h.html#abf2d63e42c92dff7424ee06eac278c60a83cc31b034e3ba1251b7f291b4a2c042", null ],
      [ "processed", "_edge_router_8h.html#abf2d63e42c92dff7424ee06eac278c60a2197be7070b386194b1df86450a31e07", null ],
      [ "used", "_edge_router_8h.html#abf2d63e42c92dff7424ee06eac278c60afdd5758990a1c290a2a9a0e8112809eb", null ]
    ] ]
];