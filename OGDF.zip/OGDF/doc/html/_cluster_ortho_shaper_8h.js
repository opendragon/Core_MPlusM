var _cluster_ortho_shaper_8h =
[
    [ "ClusterOrthoShaper", "classogdf_1_1_cluster_ortho_shaper.html", "classogdf_1_1_cluster_ortho_shaper" ],
    [ "OGDF_CLUSTER_ORTHO_SHAPER_H", "_cluster_ortho_shaper_8h.html#ada6be1198b76fa12e599b96d4fb85d2b", null ]
];