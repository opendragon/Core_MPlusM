var _fruchterman_reingold_8h =
[
    [ "FruchtermanReingold", "classogdf_1_1_fruchterman_reingold.html", "classogdf_1_1_fruchterman_reingold" ],
    [ "OGDF_FRUCHTERMAN_REINGOLD_H", "_fruchterman_reingold_8h.html#af70f30c07b7b705206f1a49320b50a7b", null ]
];