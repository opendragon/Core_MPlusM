var _hierarchy_layout_module_8h =
[
    [ "HierarchyLayoutModule", "classogdf_1_1_hierarchy_layout_module.html", "classogdf_1_1_hierarchy_layout_module" ],
    [ "OGDF_HIER_LAYOUT_MODULE_H", "_hierarchy_layout_module_8h.html#ae663beaa495b9b61b9bbc948c6f2bed2", null ]
];