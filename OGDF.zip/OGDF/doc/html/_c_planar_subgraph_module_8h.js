var _c_planar_subgraph_module_8h =
[
    [ "CPlanarSubgraphModule", "classogdf_1_1_c_planar_subgraph_module.html", "classogdf_1_1_c_planar_subgraph_module" ],
    [ "OGDF_CPLANAR_SUBGRAPH_MODULE_H", "_c_planar_subgraph_module_8h.html#ad3be253d5115b2ffac4901bf645b133e", null ]
];