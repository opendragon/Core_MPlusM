var _graph_attributes_8h =
[
    [ "GraphAttributes", "classogdf_1_1_graph_attributes.html", "classogdf_1_1_graph_attributes" ],
    [ "OGDF_ATTRIBUTED_GRAPH_H", "_graph_attributes_8h.html#aacae5a39c0829a4642093e2586ad25fb", null ]
];