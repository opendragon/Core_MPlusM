var _greedy_insert_heuristic_8h =
[
    [ "GreedyInsertHeuristic", "classogdf_1_1_greedy_insert_heuristic.html", "classogdf_1_1_greedy_insert_heuristic" ],
    [ "OGDF_GREEDY_INSERT_HEURISTIC_H", "_greedy_insert_heuristic_8h.html#a2360cae8365010c4b8c53d26f1f5685b", null ]
];