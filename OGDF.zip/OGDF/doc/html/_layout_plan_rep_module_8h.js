var _layout_plan_rep_module_8h =
[
    [ "LayoutPlanRepModule", "classogdf_1_1_layout_plan_rep_module.html", "classogdf_1_1_layout_plan_rep_module" ],
    [ "OGDF_UML_PLANAR_LAYOUT_MODULE_H", "_layout_plan_rep_module_8h.html#ac7e9735032fb625a4ca4c290e4f260ac", null ],
    [ "UMLOpt", "_layout_plan_rep_module_8h.html#a6734cb3912399f2c22c60ecba69144b9", [
      [ "umlOpAlign", "_layout_plan_rep_module_8h.html#a6734cb3912399f2c22c60ecba69144b9a6ecc8be1f1b0d04685a99980929e937f", null ],
      [ "umlOpScale", "_layout_plan_rep_module_8h.html#a6734cb3912399f2c22c60ecba69144b9ad74075f8b87faba5cda4d96f89f33310", null ],
      [ "umlOpProg", "_layout_plan_rep_module_8h.html#a6734cb3912399f2c22c60ecba69144b9a3103a90a24d156decf609fa81f5bdef0", null ]
    ] ]
];