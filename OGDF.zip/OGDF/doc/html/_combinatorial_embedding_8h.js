var _combinatorial_embedding_8h =
[
    [ "CombinatorialEmbedding", "classogdf_1_1_combinatorial_embedding.html", "classogdf_1_1_combinatorial_embedding" ],
    [ "ConstCombinatorialEmbedding", "classogdf_1_1_const_combinatorial_embedding.html", "classogdf_1_1_const_combinatorial_embedding" ],
    [ "FaceArray", "classogdf_1_1_face_array.html", "classogdf_1_1_face_array" ],
    [ "FaceElement", "classogdf_1_1_face_element.html", "classogdf_1_1_face_element" ],
    [ "forall_face_adj", "_combinatorial_embedding_8h.html#a6fe737de75afd0c3c4c6c19bcf0d7433", null ],
    [ "forall_faces", "_combinatorial_embedding_8h.html#a39e211a208a96b003303a0fc51973be0", null ],
    [ "forall_rev_faces", "_combinatorial_embedding_8h.html#a5ab2232c877edd3fb518dd702885df90", null ],
    [ "OGDF_COMBINATORIAL_EMBEDDING_H", "_combinatorial_embedding_8h.html#a03eeaaa517b9fed90f82874263da2433", null ],
    [ "face", "_combinatorial_embedding_8h.html#afc2cdb02913f6019e953897ef0c0b2d5", null ]
];