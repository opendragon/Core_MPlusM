var _e_label_interface_8h =
[
    [ "EdgeLabel", "classogdf_1_1_edge_label.html", "classogdf_1_1_edge_label" ],
    [ "ELabelInterface", "classogdf_1_1_e_label_interface.html", "classogdf_1_1_e_label_interface" ],
    [ "OGDF_E_LABEL_INTERFACE_H", "_e_label_interface_8h.html#a8d7be23d4e6626efbcfcc4aa295c5b44", null ],
    [ "eLabelType", "_e_label_interface_8h.html#a2d457cc725540c7bec73e6eb92c5a357", [
      [ "elEnd1", "_e_label_interface_8h.html#a2d457cc725540c7bec73e6eb92c5a357ab955f36b0c66dd7a14a8097ccfb6ed0a", null ],
      [ "elMult1", "_e_label_interface_8h.html#a2d457cc725540c7bec73e6eb92c5a357a5620667f5d95b5930bbf138661b3d3dd", null ],
      [ "elName", "_e_label_interface_8h.html#a2d457cc725540c7bec73e6eb92c5a357a7f94f92f9c727925bf6881c417a3cec7", null ],
      [ "elEnd2", "_e_label_interface_8h.html#a2d457cc725540c7bec73e6eb92c5a357a17246d0edce72845636849ff4c68c9e3", null ],
      [ "elMult2", "_e_label_interface_8h.html#a2d457cc725540c7bec73e6eb92c5a357aa3e5990f890497254fdc53953bd2ad48", null ],
      [ "elNumLabels", "_e_label_interface_8h.html#a2d457cc725540c7bec73e6eb92c5a357ad537bcbf2c32d85e06abab8e702a15a3", null ]
    ] ],
    [ "eUsedLabels", "_e_label_interface_8h.html#adf517d97fcef2b7b1dd0f9b5feec3478", [
      [ "lEnd1", "_e_label_interface_8h.html#adf517d97fcef2b7b1dd0f9b5feec3478a4371fc9eb27b046cf7b0bca9f4713e68", null ],
      [ "lMult1", "_e_label_interface_8h.html#adf517d97fcef2b7b1dd0f9b5feec3478a2499a0317e8ed6d5e548a50b58f3de1f", null ],
      [ "lName", "_e_label_interface_8h.html#adf517d97fcef2b7b1dd0f9b5feec3478aabb111115d49a74ff4f6ac58f00fb9d2", null ],
      [ "lEnd2", "_e_label_interface_8h.html#adf517d97fcef2b7b1dd0f9b5feec3478a59f2d2de09c23483debb7bd4548465ba", null ],
      [ "lMult2", "_e_label_interface_8h.html#adf517d97fcef2b7b1dd0f9b5feec3478a786f4a6e04f47658bc14ed065b97ce8c", null ],
      [ "lAll", "_e_label_interface_8h.html#adf517d97fcef2b7b1dd0f9b5feec3478ae8b49404d0d63e808ef0a0c13d97d0b2", null ]
    ] ]
];