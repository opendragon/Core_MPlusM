var _graph_copy_8h =
[
    [ "GraphCopy", "classogdf_1_1_graph_copy.html", "classogdf_1_1_graph_copy" ],
    [ "GraphCopySimple", "classogdf_1_1_graph_copy_simple.html", "classogdf_1_1_graph_copy_simple" ],
    [ "OGDF_GRAPH_COPY_H", "_graph_copy_8h.html#ae112ce2d3016eff747be15701c7d5295", null ]
];