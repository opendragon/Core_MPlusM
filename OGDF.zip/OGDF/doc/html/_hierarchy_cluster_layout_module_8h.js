var _hierarchy_cluster_layout_module_8h =
[
    [ "HierarchyClusterLayoutModule", "classogdf_1_1_hierarchy_cluster_layout_module.html", "classogdf_1_1_hierarchy_cluster_layout_module" ],
    [ "OGDF_HIER_CLUSTER_LAYOUT_MODULE_H", "_hierarchy_cluster_layout_module_8h.html#a38d0964c2905a5df4c056b097bf06226", null ]
];