var _embedder_min_depth_max_face_layers_8h =
[
    [ "EmbedderMinDepthMaxFaceLayers", "classogdf_1_1_embedder_min_depth_max_face_layers.html", "classogdf_1_1_embedder_min_depth_max_face_layers" ],
    [ "OGDF_EMBEDDER_MIN_DEPTH_MAX_FACE_Layers_H", "_embedder_min_depth_max_face_layers_8h.html#a0ea45bf7ce1dc57d3176ebc1cd0c09ea", null ]
];