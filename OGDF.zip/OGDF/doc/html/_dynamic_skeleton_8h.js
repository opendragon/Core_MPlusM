var _dynamic_skeleton_8h =
[
    [ "DynamicSkeleton", "classogdf_1_1_dynamic_skeleton.html", "classogdf_1_1_dynamic_skeleton" ],
    [ "OGDF_DYNAMIC_SKELETON_H", "_dynamic_skeleton_8h.html#a38f37d531a539c77c778cd557595e546", null ]
];