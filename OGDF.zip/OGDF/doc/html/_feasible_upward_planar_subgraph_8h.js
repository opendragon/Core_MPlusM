var _feasible_upward_planar_subgraph_8h =
[
    [ "FeasibleUpwardPlanarSubgraph", "classogdf_1_1_feasible_upward_planar_subgraph.html", "classogdf_1_1_feasible_upward_planar_subgraph" ],
    [ "OGDF_FEASIBLE_UPWARD_PLANAR_SUBGRAPH_H", "_feasible_upward_planar_subgraph_8h.html#a2e7a0c941abf239650e6ea4475182700", null ]
];