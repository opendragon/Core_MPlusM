var _augmentation_module_8h =
[
    [ "AugmentationModule", "classogdf_1_1_augmentation_module.html", "classogdf_1_1_augmentation_module" ],
    [ "OGDF_AUGMENTATION_MODULE_H", "_augmentation_module_8h.html#adc83186c27853d725038abed44dd370a", null ]
];