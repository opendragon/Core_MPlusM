var _circle_placer_8h =
[
    [ "CirclePlacer", "classogdf_1_1_circle_placer.html", "classogdf_1_1_circle_placer" ],
    [ "OGDF_CIRCLE_PLACER_H", "_circle_placer_8h.html#af415c584d41743dbf72a8c82fef9915f", null ]
];