var _edge_comparer_8h =
[
    [ "EdgeComparer", "classogdf_1_1_edge_comparer.html", "classogdf_1_1_edge_comparer" ],
    [ "OGDF_EDGECOMPARER_H", "_edge_comparer_8h.html#af491d00c54cc3eaf5a292310e448bc0f", null ]
];