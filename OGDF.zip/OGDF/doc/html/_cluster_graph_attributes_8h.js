var _cluster_graph_attributes_8h =
[
    [ "ClusterGraphAttributes", "classogdf_1_1_cluster_graph_attributes.html", "classogdf_1_1_cluster_graph_attributes" ],
    [ "ClusterInfo", "classogdf_1_1_cluster_info.html", "classogdf_1_1_cluster_info" ],
    [ "OGDF_CLUSTER_GRAPH_ATTRIBUTES_H", "_cluster_graph_attributes_8h.html#ac490e39a9b028c4d17d9248f3384d308", null ]
];