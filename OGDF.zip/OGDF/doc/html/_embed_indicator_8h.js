var _embed_indicator_8h =
[
    [ "EmbedIndicator", "classogdf_1_1_embed_indicator.html", "classogdf_1_1_embed_indicator" ],
    [ "OGDF_EMBED_INDICATOR_H", "_embed_indicator_8h.html#ab0e298295b9a9b0ab00d1ef8c7de176c", null ]
];