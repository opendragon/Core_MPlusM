var _edge_attributes_8h =
[
    [ "EdgeAttributes", "classogdf_1_1_edge_attributes.html", "classogdf_1_1_edge_attributes" ],
    [ "OGDF_EDGE_ATTRIBUTES_H", "_edge_attributes_8h.html#a0786420c11befc7ca38d9904a74d571b", null ]
];