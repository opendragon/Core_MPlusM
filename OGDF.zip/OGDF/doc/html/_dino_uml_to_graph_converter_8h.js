var _dino_uml_to_graph_converter_8h =
[
    [ "DinoUmlToGraphConverter", "classogdf_1_1_dino_uml_to_graph_converter.html", "classogdf_1_1_dino_uml_to_graph_converter" ],
    [ "OGDF_DINO_UML_TO_GRAPH_CONVERTER_H", "_dino_uml_to_graph_converter_8h.html#ab026b947d0713e305dd68e615806c4f9", null ]
];