var _greedy_switch_heuristic_8h =
[
    [ "GreedySwitchHeuristic", "classogdf_1_1_greedy_switch_heuristic.html", "classogdf_1_1_greedy_switch_heuristic" ],
    [ "OGDF_GREEDY_SWITCH_HEURISTIC_H", "_greedy_switch_heuristic_8h.html#af699687e95816ca5f38200e84a18c279", null ]
];