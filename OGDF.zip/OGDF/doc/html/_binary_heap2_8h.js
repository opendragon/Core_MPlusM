var _binary_heap2_8h =
[
    [ "BinaryHeap2", "classogdf_1_1_binary_heap2.html", "classogdf_1_1_binary_heap2" ],
    [ "HeapEntry", "structogdf_1_1_binary_heap2_1_1_heap_entry.html", "structogdf_1_1_binary_heap2_1_1_heap_entry" ],
    [ "OGDF_BINARY_HEAP2_H", "_binary_heap2_8h.html#a995c0bb27e10d122ebc8e537cabcac89", null ]
];