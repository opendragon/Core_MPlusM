var _dino_uml_diagram_graph_8h =
[
    [ "DinoUmlDiagramGraph", "classogdf_1_1_dino_uml_diagram_graph.html", "classogdf_1_1_dino_uml_diagram_graph" ],
    [ "OGDF_DINO_UML_DIAGRAM_GRAPH_H", "_dino_uml_diagram_graph_8h.html#a59b74075b3a50d3fb9733d3caf513a29", null ],
    [ "operator<<", "_dino_uml_diagram_graph_8h.html#a7cd52bbdd721eed5cd314d7b53cd11b3", null ]
];