// $Id: Connection_Recycling_Strategy.cpp 97246 2013-08-07 07:10:20Z johnnyw $

#include "ace/Connection_Recycling_Strategy.h"

ACE_BEGIN_VERSIONED_NAMESPACE_DECL

ACE_Connection_Recycling_Strategy::ACE_Connection_Recycling_Strategy (void)
{
}

ACE_Connection_Recycling_Strategy::~ACE_Connection_Recycling_Strategy (void)
{
}

ACE_END_VERSIONED_NAMESPACE_DECL
