// $Id: IO_Cntl_Msg.cpp 92069 2010-09-28 11:38:59Z johnnyw $

#include "ace/IO_Cntl_Msg.h"

#if !defined (__ACE_INLINE__)
#include "ace/IO_Cntl_Msg.inl"
#endif /* __ACE_INLINE__ */
