// $Id: config-macosx-iOS-simulator.h 97580 2014-02-11 17:56:01Z sowayaa $
#ifndef ACE_CONFIG_MACOSX_IPHONE_SIMULATOR_H
#define ACE_CONFIG_MACOSX_IPHONE_SIMULATOR_H

#define ACE_HAS_IPHONE
#include "ace/config-macosx-mavericks.h"

#endif /* ACE_CONFIG_MACOSX_IPHONE_SIMULATOR_H */

